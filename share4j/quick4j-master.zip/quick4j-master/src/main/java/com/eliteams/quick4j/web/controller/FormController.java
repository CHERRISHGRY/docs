package com.eliteams.quick4j.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 表单控制器
 * 
 * @author starzou
 * @since 2014年4月13日 下午5:22:20
 **/
@Controller
@RequestMapping("/form")
public class FormController {

}