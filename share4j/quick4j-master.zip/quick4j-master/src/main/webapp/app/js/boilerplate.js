define([
  'jquery',
  'underscore',
  'backbone'
], function($, _, Backbone){
  return {};
});